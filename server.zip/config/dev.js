module.exports = {
    mongoURI: 'mongodb://localhost:27017/MRRA',
    jwtSecret: 'kdjkasjqr8239r8kfj939kdjkdjfkwfdqwfwqfwqfwt944039043kjgkwjgkwgwlkg404204wegklgkt42-owpglw4-y34pyo3py0239tfkeit049igkjkvjvw049t09tofjkwrjt034tigdfkjgkdfjg0rt9304fsdkfj04t904gigo',
    jwtExpire: '24h',
    api_key: "",
    DOMAIN: '',
    cloudinary_cloud_name: '',
    cloudinary_api_key: '',
    cloudinary_api_secret: '',
    EMAIL: '',
    PASSWORD: "",
    stripe_secret: ""
} 
